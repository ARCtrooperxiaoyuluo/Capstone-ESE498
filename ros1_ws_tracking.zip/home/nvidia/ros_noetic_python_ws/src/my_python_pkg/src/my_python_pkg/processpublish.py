#!/usr/bin/env python

# adapted from main.py to ros1 publish node 
# Description:
# yolov5 detect the person, deepsort tracked the person, drawing a bounding box of the tracked person and assign a 
# uniqe ID, depth camera d435i get the depth and angle data of the center of the bounding box. 
# publish depth and angle of tracking object (1 person)
# track the first person detected after the node started
# if the tracked person disappeared from frame for extended period of time, restart the node

# use: in one terminal, roscore; in another terminal, rosrun my_python_pkg processpublish.py

# import dependencies
import os
import threading
import numpy as np
import sys
import torch
import cv2
import pyrealsense2 as rs
import rospy
from std_msgs.msg import Float32
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
yolov5_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'yolov5'))
sys.path.append(yolov5_path)
from yolov5.models.common import DetectMultiBackend
from yolov5.utils.general import LOGGER, check_img_size, non_max_suppression, scale_coords, xyxy2xywh
from yolov5.utils.plots import Annotator, colors
from yolov5.utils.torch_utils import select_device, time_sync
from deep_sort_pytorch.utils.parser import get_config
from deep_sort_pytorch.deep_sort import DeepSort

# publish node
class RealSenseTrackingNode:
    def __init__(self):
        rospy.init_node('realsense_tracking_node')
        
        self.depth_pub = rospy.Publisher('depth_data', Float32, queue_size=10)
        self.angle_pub = rospy.Publisher('angle_data', Float32, queue_size=10)

        # Initialize depth camera d435i
        self.pipeline = rs.pipeline()
        self.config = rs.config()
        self.config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
        self.config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
        self.pipeline.start(self.config)
        self.align_to = rs.stream.color
        self.align = rs.align(self.align_to)

        # Load YOLO model
        self.device = select_device("0") # cuda 0, cpu 
        self.model = DetectMultiBackend('yolov5s.pt', device=self.device) # yolov5x.pt also available
        self.imgsz = check_img_size([640], s=self.model.stride)

        # Initialize DeepSort
        self.cfg = get_config()
        self.cfg.merge_from_file("/opt/ros/noetic/lib/python3/dist-packages/deep_sort_pytorch/configs/deep_sort.yaml")
        self.deepsort = DeepSort('/opt/ros/noetic/lib/python3/dist-packages/deep_sort_pytorch/deep_sort/deep/checkpoint/ckpt.t7',
                                 max_dist=self.cfg.DEEPSORT.MAX_DIST,
                                 min_confidence=self.cfg.DEEPSORT.MIN_CONFIDENCE,
                                 max_iou_distance=self.cfg.DEEPSORT.MAX_IOU_DISTANCE,
                                 max_age=self.cfg.DEEPSORT.MAX_AGE,
                                 n_init=self.cfg.DEEPSORT.N_INIT,
                                 nn_budget=self.cfg.DEEPSORT.NN_BUDGET,
                                 use_cuda=self.device.type != 'cpu')

     
        self.depth_value = None
        self.angle_value = None
        self.first_person_id = None

        # image capturing and processing in one thread
        # publish data in another thread
        self.image_thread = threading.Thread(target=self.process_image)
        self.image_thread.daemon = True
        self.image_thread.start()

        # publish rate
        self.publish_rate = 10
        self.timer = rospy.Timer(rospy.Duration(1 / self.publish_rate), self.publish_data)

    def process_image(self):
        while not rospy.is_shutdown():
            # Capture frames
            frames = self.pipeline.wait_for_frames()
            aligned_frames = self.align.process(frames)
            color_frame = aligned_frames.get_color_frame()
            depth_frame = aligned_frames.get_depth_frame()
            if not color_frame or not depth_frame:
                continue

            # Convert frames to numpy arrays
            im0 = np.asanyarray(color_frame.get_data())
            depth_image = np.asanyarray(depth_frame.get_data())

            # Preprocess the image for YOLO
            img = cv2.cvtColor(im0, cv2.COLOR_BGR2RGB)
            img = img.transpose((2, 0, 1))  # HWC to CHW
            img = np.ascontiguousarray(img)
            img = torch.from_numpy(img).to(self.device).float() / 255.0
            if img.ndimension() == 3:
                img = img.unsqueeze(0)

            # Run Yolo inference
            pred = self.model(img)
            pred = non_max_suppression(pred, 0.4, 0.5, classes=[0])  # Only detect humans (class 0)

            detected_ids = []
            # process the predictions
            for i, det in enumerate(pred): 
                annotator = Annotator(im0, line_width=2)
		# det: 0:4--[x_center, y_center, width, height], 4--confindence score, 5--object class
                if det is not None and len(det):
                    # Rescale boxes from img_size to original image size
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                    # Prepare detections for DeepSort
                    xywhs = xyxy2xywh(det[:, 0:4])  # Convert to [x_center, y_center, width, height]
                    confs = det[:, 4]  # Confidence scores
                    # Pass detections to DeepSort
                    outputs = self.deepsort.update(xywhs.cpu(), confs.cpu(), det[:, 5].cpu(), im0)
		
		     # get depth and angle of center of the tracking box
                    for j, (output, conf) in enumerate(zip(outputs, confs)):
                        bboxes = output[0:4]  # Bounding box coordinates
                        track_id = output[4]  # Track ID
                        detected_ids.append(track_id)

                        # If it's the first person detected, store their track ID
                        if self.first_person_id is None:
                            self.first_person_id = track_id

                        if self.first_person_id == track_id:
                            # Calculate depth at bounding box center
                            x_center = int((bboxes[0] + bboxes[2]) / 2)
                            y_center = int((bboxes[1] + bboxes[3]) / 2)
                            depth_value = depth_frame.get_distance(x_center, y_center)
                            angle = -0.09375 * x_center + 30  # Angle calculation based on x_center

                            # Store depth and angle values for publishing
                            self.depth_value = depth_value
                            self.angle_value = angle

            # If the first person is not detected anymore, reset depth and angle
            if self.first_person_id is not None and self.first_person_id not in detected_ids:
                self.depth_value = 1.20
                self.angle_value = 0

    def publish_data(self, event=None):
        # Publish depth and angle data from the main thread
        if self.depth_value is not None and self.angle_value is not None:
            depth_msg = Float32()
            depth_msg.data = self.depth_value
            self.depth_pub.publish(depth_msg)
            angle_msg = Float32()
            angle_msg.data = self.angle_value
            self.angle_pub.publish(angle_msg)

            rospy.loginfo(f"Published Depth: {self.depth_value:.2f}m, Angle: {self.angle_value:.2f}°")

    def stop(self):
        self.pipeline.stop()


def main():
    realsense_tracking_node = RealSenseTrackingNode()
    try:
        rospy.spin()  # Keep the node running
    except KeyboardInterrupt:
        pass
    finally:
        realsense_tracking_node.stop()


if __name__ == '__main__':
    main()

