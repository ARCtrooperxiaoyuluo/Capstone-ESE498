# simplified from realtrack.py which only focus on d435i real time tracking
# depth and angle to object measured
# assume only one predicted box
# use: python main.py

import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
import numpy as np
import sys
sys.path.insert(0, './yolov5')

from yolov5.models.common import DetectMultiBackend
from yolov5.utils.general import LOGGER, check_img_size, non_max_suppression, scale_coords, xyxy2xywh
from yolov5.utils.plots import Annotator, colors
from yolov5.utils.torch_utils import select_device, time_sync
from deep_sort_pytorch.utils.parser import get_config
from deep_sort_pytorch.deep_sort import DeepSort

import cv2
import torch
import pyrealsense2 as rs

def detect():
    # Initialize RealSense

    pipeline = rs.pipeline()
    config = rs.config()
    config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
    config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
    pipeline.start(config)
    align_to = rs.stream.color
    align = rs.align(align_to)

    # Load YOLO model
    device = select_device("0")
    model = DetectMultiBackend('yolov5s.pt', device=device)
    imgsz = check_img_size([640], s=model.stride)  # Ensure image size is valid

    # Initialize DeepSort
    cfg = get_config()
    cfg.merge_from_file("deep_sort_pytorch/configs/deep_sort.yaml")
    deepsort = DeepSort(cfg.DEEPSORT.REID_CKPT,
                        max_dist=cfg.DEEPSORT.MAX_DIST,
                        min_confidence=cfg.DEEPSORT.MIN_CONFIDENCE,
                        max_iou_distance=cfg.DEEPSORT.MAX_IOU_DISTANCE,
                        max_age=cfg.DEEPSORT.MAX_AGE,
                        n_init=cfg.DEEPSORT.N_INIT,
                        nn_budget=cfg.DEEPSORT.NN_BUDGET,
                        use_cuda=(device.type == 'cuda'))

    while True:
        start_time = time_sync()  # Start measuring the frame processing time

        # Capture RealSense frames
        frames = pipeline.wait_for_frames()
        aligned_frames = align.process(frames)
        color_frame = aligned_frames.get_color_frame()
        depth_frame = aligned_frames.get_depth_frame()

        if not color_frame or not depth_frame:
            continue

        # Convert frames to numpy arrays
        im0 = np.asanyarray(color_frame.get_data())
        depth_image = np.asanyarray(depth_frame.get_data())

        # Preprocess the image for YOLO
        img = cv2.cvtColor(im0, cv2.COLOR_BGR2RGB)
        img = img.transpose((2, 0, 1))  # HWC to CHW
        img = np.ascontiguousarray(img)
        img = torch.from_numpy(img).to(device).float() / 255.0  # Normalize
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Run inference
        pred = model(img)
        pred = non_max_suppression(pred, 0.4, 0.5, classes=[0])  # Only detect humans (class 0)


        for i, det in enumerate(pred):  # detections per image
            annotator = Annotator(im0, line_width=2)

            if det is not None and len(det):
                # Rescale boxes from img_size to original image size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # Prepare detections for DeepSort
                xywhs = xyxy2xywh(det[:, 0:4])  # Convert to [x_center, y_center, width, height]
                confs = det[:, 4]  # Confidence scores

                # Pass detections to DeepSort
                outputs = deepsort.update(xywhs.cpu(), confs.cpu(), det[:, 5].cpu(), im0)

                for j, (output, conf) in enumerate(zip(outputs, confs)):
                    bboxes = output[0:4]  # Bounding box coordinates
                    id = output[4]  # Track ID

                    # Calculate depth at bounding box center
                    x_center = int((bboxes[0] + bboxes[2]) / 2)
                    y_center = int((bboxes[1] + bboxes[3]) / 2)
                    depth_value = depth_frame.get_distance(x_center, y_center)
                    angle = -0.09375 * x_center + 30

                    # Annotate the image
                    label = f"ID {id} | Depth: {depth_value:.2f}m"
                    annotator.box_label(bboxes, label, color=colors(0, True))

                    print(f"ID {id} detected at ({x_center}, {y_center}), Depth: {depth_value:.2f} meters, Angle: {angle:.2f}°")

            # Display the image
            im0 = annotator.result()
            cv2.imshow('Detection', im0)
            if cv2.waitKey(1) == ord('q'):  # Press 'q' to quit
                break

        end_time = time_sync()  # End timing the frame processing time
        frame_time = end_time - start_time
        print(f"Time taken to process one frame: {frame_time:.4f} seconds")

    # Release RealSense pipeline
    pipeline.stop()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    detect()
