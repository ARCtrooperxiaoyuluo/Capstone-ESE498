#!/usr/bin/env python

# a subscribe and publish node
 
# subscribe depth and angle data published from processpublish.py node
# PID controller
# publish x_acceleration and z_angular_acceleration as Twist message

# use: roscore, rosrun my_python_pkg processpublish.py, rosrun my_python_pkg pidspeed.py in seprate terminals and follow the order. 


import rospy
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist

# PID controller 
class PIDController:
    def __init__(self, kp, ki, kd, setpoint):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.setpoint = setpoint
        self.previous_error = 0
        self.integral = 0

    def compute(self, measurement):
        error = self.setpoint - measurement
        self.integral += error
        derivative = error - self.previous_error
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.previous_error = error
        return -output 


class RealSenseControlNode:
    def __init__(self):
        rospy.init_node('realsense_control_node', anonymous=True)
        
        # Subscribers
        self.depth_sub = rospy.Subscriber('depth_data', Float32, self.depth_callback)
        self.angle_sub = rospy.Subscriber('angle_data', Float32, self.angle_callback)
        # Publisher for Twist message
        self.cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)

        # PID Controllers, tune PID values here, change reference values here 
        self.depth_pid = PIDController(kp=0.75, ki=0.0, kd=0.0, setpoint=1.2)  # Reference depth: 1.2 meters
        self.angle_pid = PIDController(kp=0.02, ki=0.0, kd=0.01, setpoint=0.0)  # Reference angle: 0 degrees

	# first order filter
        self.current_depth = None
        self.current_angle = None
        self.filtered_x_accel = 0.0
        self.filtered_z_accel = 0.0
        self.filter_alpha = 0.7  # Tune smoothing factor (0 < alpha <= 1) here 

        # Acceleration bounds
        self.x_accel_bounds = (-1.5, 1.5)  # Lower and upper bounds for x_accel
        self.z_accel_bounds = (-0.7, 0.7)  # Lower and upper bounds for z_accel_angular

        # rate
        self.publish_rate = 10  # 10 Hz
        self.timer = rospy.Timer(rospy.Duration(1.0 / self.publish_rate), self.publish_twist)

    def depth_callback(self, msg):
        self.current_depth = msg.data

    def angle_callback(self, msg):
        self.current_angle = msg.data

    def clamp(self, value, lower, upper):
        return max(lower, min(value, upper))

    def publish_twist(self, event=None):
        if self.current_depth is not None and self.current_angle is not None:
            # Compute PID outputs
            raw_x_accel = self.depth_pid.compute(self.current_depth)
            raw_z_accel = self.angle_pid.compute(self.current_angle)

            # Clamp values to bounds
            clamped_x_accel = self.clamp(raw_x_accel, *self.x_accel_bounds)
            clamped_z_accel = self.clamp(raw_z_accel, *self.z_accel_bounds)

            # Apply first-order filter
            self.filtered_x_accel = self.filter_alpha * clamped_x_accel + (1 - self.filter_alpha) * self.filtered_x_accel
            self.filtered_z_accel = self.filter_alpha * clamped_z_accel + (1 - self.filter_alpha) * self.filtered_z_accel

            # Publish Twist message
            twist_msg = Twist()
            twist_msg.linear.x = self.filtered_x_accel
            twist_msg.angular.z = self.filtered_z_accel
            self.cmd_vel_pub.publish(twist_msg)
            rospy.loginfo(f"Published Twist: Linear X: {self.filtered_x_accel:.2f}, Angular Z: {self.filtered_z_accel:.2f}")


def main():
    realsense_control_node = RealSenseControlNode()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        pass
    finally:
        rospy.loginfo("Shutting down ROS1 node")


if __name__ == '__main__':
    main()

