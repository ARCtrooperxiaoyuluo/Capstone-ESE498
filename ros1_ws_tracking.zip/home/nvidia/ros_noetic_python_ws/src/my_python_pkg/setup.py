from setuptools import setup

setup(
    name='my_python_pkg',
    version='0.1.0',
    packages=['my_python_pkg'],
    install_requires=[
        'rospy',  # You can list other dependencies here
    ],
    entry_points={
        'console_scripts': [
            'processpublish = my_python_pkg.processpublish:main', 
            'pidspeed = my_python_pkg.pidspeed:main',
        ],
    },
)
